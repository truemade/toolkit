# SCRIPTS #
The scripts here consists of 3 types:

## Blender scripts ##
- blender.py

## Blender add-ons ##
- lightmap_apply_addon.py

## Support scripts ##
- png2jpg.py

For Blender scripts, these has to be loaded at scripting tab at Blender.

For Blender add-ons, these has to be loaded at properties menu at Blender.

For support scripts, these can be run as a common python script.

